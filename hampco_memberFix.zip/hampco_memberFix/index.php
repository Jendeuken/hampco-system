

<?php include "header.php"?>



<div class="bg-gray-100 flex items-center justify-center min-h-screen bg-cover bg-center" style="background-image: url('assets/image/banner.jpg');">


</div>

<?php include "footer.php";?>