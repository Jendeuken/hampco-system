-- Drop existing view
DROP VIEW IF EXISTS member_earnings_summary;

-- Create updated view
CREATE OR REPLACE VIEW member_earnings_summary AS
SELECT 
    member_id,
    COUNT(*) as total_tasks,
    SUM(CASE WHEN payment_status = 'Pending' THEN total_amount ELSE 0 END) as pending_payments,
    SUM(CASE WHEN payment_status = 'Paid' THEN total_amount ELSE 0 END) as completed_payments,
    SUM(total_amount) as total_earnings
FROM payment_records
GROUP BY member_id; 