-- Drop existing view if it exists
DROP VIEW IF EXISTS payment_records_view;

-- Create updated view
CREATE OR REPLACE VIEW payment_records_view AS
SELECT 
    pr.id,
    pr.production_id,
    um.fullname AS member_name,
    CASE 
        WHEN pr.is_self_assigned = 1 THEN mst.product_name
        ELSE pl.product_name
    END as product_name,
    CASE 
        WHEN pr.is_self_assigned = 0 AND pl.product_name IN ('Piña Seda', 'Pure Piña Cloth') 
        THEN CONCAT(COALESCE(pl.length_m, 0), 'm x ', COALESCE(pl.width_m, 0), 'm')
        ELSE '-'
    END AS measurements,
    CASE 
        WHEN pr.is_self_assigned = 1 THEN mst.weight_g
        ELSE pl.weight_g
    END as weight_g,
    CASE 
        WHEN (pr.is_self_assigned = 0 AND pl.product_name IN ('Piña Seda', 'Pure Piña Cloth'))
        OR (pr.is_self_assigned = 1 AND mst.product_name IN ('Piña Seda', 'Pure Piña Cloth'))
        THEN pr.quantity
        ELSE NULL
    END AS quantity,
    pr.unit_rate,
    pr.total_amount,
    pr.payment_status,
    pr.date_paid,
    pr.is_self_assigned
FROM payment_records pr
INNER JOIN user_member um ON pr.member_id = um.id
LEFT JOIN member_self_tasks mst ON pr.production_id = mst.production_id AND pr.is_self_assigned = 1
LEFT JOIN production_line pl ON 
    (pr.is_self_assigned = 0 AND pl.prod_line_id = CAST(pr.production_id AS UNSIGNED)) OR
    (pr.is_self_assigned = 1 AND pl.prod_line_id = CAST(SUBSTRING(pr.production_id, 3) AS UNSIGNED)); 