-- Drop existing views
DROP VIEW IF EXISTS member_balance_view;
DROP VIEW IF EXISTS member_earnings_summary;

-- Create updated member balance view
CREATE OR REPLACE VIEW member_balance_view AS
SELECT 
    pr.id,
    pr.member_id,
    CASE 
        WHEN pr.is_self_assigned = 1 THEN mst.product_name
        ELSE pl.product_name
    END as product_name,
    pr.weight_g,
    CASE 
        WHEN pr.is_self_assigned = 0 AND pl.product_name IN ('Piña Seda', 'Pure Piña Cloth') 
        THEN CONCAT(COALESCE(pl.length_m, 0), 'm x ', COALESCE(pl.width_m, 0), 'm')
        ELSE '-'
    END AS measurements,
    CASE 
        WHEN (pr.is_self_assigned = 0 AND pl.product_name IN ('Piña Seda', 'Pure Piña Cloth'))
        OR (pr.is_self_assigned = 1 AND mst.product_name IN ('Piña Seda', 'Pure Piña Cloth'))
        THEN pr.quantity
        ELSE 1
    END AS quantity,
    pr.unit_rate,
    pr.total_amount,
    pr.payment_status,
    pr.date_paid,
    pr.date_created,
    um.role as member_role
FROM payment_records pr
JOIN user_member um ON pr.member_id = um.id
LEFT JOIN production_line pl ON 
    CASE 
        WHEN pr.is_self_assigned = 0 THEN CAST(pr.production_id AS UNSIGNED) = pl.prod_line_id
        ELSE FALSE
    END
LEFT JOIN member_self_tasks mst ON 
    CASE 
        WHEN pr.is_self_assigned = 1 THEN pr.production_id = mst.production_id
        ELSE FALSE
    END
WHERE pr.payment_status IN ('Pending', 'Paid', 'Adjusted')
ORDER BY pr.date_created DESC;

-- Create updated member earnings summary view
CREATE OR REPLACE VIEW member_earnings_summary AS
SELECT 
    member_id,
    COUNT(*) as total_tasks,
    SUM(CASE WHEN payment_status = 'Pending' THEN total_amount ELSE 0 END) as pending_payments,
    SUM(CASE WHEN payment_status = 'Paid' THEN total_amount ELSE 0 END) as completed_payments,
    SUM(total_amount) as total_earnings
FROM payment_records
GROUP BY member_id; 