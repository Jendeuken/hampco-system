-- Drop existing trigger
DROP TRIGGER IF EXISTS after_task_completion;

DELIMITER //

CREATE TRIGGER after_task_completion
AFTER UPDATE ON task_assignments
FOR EACH ROW
BEGIN
    IF NEW.status = 'completed' AND OLD.status != 'completed' THEN
        INSERT INTO payment_records (
            member_id,
            production_id,
            length_m,
            width_m,
            weight_g,
            quantity,
            unit_rate,
            total_amount,
            is_self_assigned,
            payment_status,
            date_created
        )
        SELECT 
            NEW.member_id,
            CAST(NEW.prod_line_id AS CHAR),
            pl.length_m,
            pl.width_m,
            pl.weight_g,
            CASE 
                WHEN pl.product_name IN ('Piña Seda', 'Pure Piña Cloth') THEN pl.quantity
                ELSE 1
            END,
            CASE 
                WHEN pl.product_name = 'Knotted Liniwan' THEN 50.00
                WHEN pl.product_name = 'Knotted Bastos' THEN 50.00
                WHEN pl.product_name = 'Warped Silk' THEN 19.00
                WHEN pl.product_name IN ('Piña Seda', 'Pure Piña Cloth') THEN 550.00
                ELSE 0.00
            END,
            CASE 
                WHEN pl.product_name IN ('Piña Seda', 'Pure Piña Cloth') THEN
                    pl.length_m * 550.00 * pl.quantity
                ELSE
                    pl.weight_g * 
                    CASE 
                        WHEN pl.product_name = 'Knotted Liniwan' THEN 50.00
                        WHEN pl.product_name = 'Knotted Bastos' THEN 50.00
                        WHEN pl.product_name = 'Warped Silk' THEN 19.00
                        ELSE 0.00
                    END
            END,
            0,
            'Pending',
            NOW()
        FROM production_line pl
        WHERE pl.prod_line_id = NEW.prod_line_id;
    END IF;
END //

DELIMITER ;

-- Update existing regular task payment records with correct rates and calculations
UPDATE payment_records pr
JOIN production_line pl ON CAST(pr.production_id AS UNSIGNED) = pl.prod_line_id
SET 
    pr.unit_rate = CASE 
        WHEN pl.product_name = 'Knotted Liniwan' THEN 50.00
        WHEN pl.product_name = 'Knotted Bastos' THEN 50.00
        WHEN pl.product_name = 'Warped Silk' THEN 19.00
        WHEN pl.product_name IN ('Piña Seda', 'Pure Piña Cloth') THEN 550.00
        ELSE pr.unit_rate
    END,
    pr.total_amount = CASE 
        WHEN pl.product_name IN ('Piña Seda', 'Pure Piña Cloth') THEN
            pl.length_m * 550.00 * pl.quantity
        ELSE
            pl.weight_g * 
            CASE 
                WHEN pl.product_name = 'Knotted Liniwan' THEN 50.00
                WHEN pl.product_name = 'Knotted Bastos' THEN 50.00
                WHEN pl.product_name = 'Warped Silk' THEN 19.00
                ELSE pr.unit_rate
            END
    END
WHERE pr.is_self_assigned = 0; 