<?php
session_start();
require_once '../../../function/database.php';

header('Content-Type: application/json');

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Not logged in'
    ]);
    exit;
}

$db = new Database();
$member_id = $_SESSION['id'];
$filter = $_GET['filter'] ?? 'all';

try {
    // Get member role
    $role_query = "SELECT role FROM user_member WHERE id = ?";
    $stmt = $db->conn->prepare($role_query);
    if (!$stmt) {
        throw new Exception("Role query prepare failed: " . $db->conn->error);
    }

    $stmt->bind_param("i", $member_id);
    if (!$stmt->execute()) {
        throw new Exception("Role query execute failed: " . $stmt->error);
    }

    $role_result = $stmt->get_result();
    if (!$role_result) {
        throw new Exception("Role query result failed: " . $stmt->error);
    }

    $role_data = $role_result->fetch_assoc();
    if (!$role_data) {
        throw new Exception("Member not found");
    }

    $member_role = strtolower($role_data['role']);
    $stmt->close();

    // Prepare date filter condition
    $date_condition = '';
    switch ($filter) {
        case 'this_month':
            $date_condition = 'AND MONTH(pr.date_created) = MONTH(CURRENT_DATE()) AND YEAR(pr.date_created) = YEAR(CURRENT_DATE())';
            break;
        case 'last_month':
            $date_condition = 'AND MONTH(pr.date_created) = MONTH(DATE_SUB(CURRENT_DATE(), INTERVAL 1 MONTH)) AND YEAR(pr.date_created) = YEAR(DATE_SUB(CURRENT_DATE(), INTERVAL 1 MONTH))';
            break;
        case 'this_year':
            $date_condition = 'AND YEAR(pr.date_created) = YEAR(CURRENT_DATE())';
            break;
        default:
            $date_condition = '';
    }

    // Query payment records
    $query = "SELECT 
        pr.*,
        CASE 
            WHEN pr.is_self_assigned = 1 THEN mst.product_name
            ELSE pl.product_name
        END as product_name,
        CASE 
            WHEN pl.product_name IN ('Piña Seda', 'Pure Piña Cloth') 
            THEN CONCAT(COALESCE(pl.length_m, 0), 'm x ', COALESCE(pl.width_m, 0), 'm')
            ELSE '-'
        END AS measurements
    FROM payment_records pr
    LEFT JOIN production_line pl ON (pr.is_self_assigned = 0 AND CAST(pr.production_id AS UNSIGNED) = pl.prod_line_id)
    LEFT JOIN member_self_tasks mst ON (pr.is_self_assigned = 1 AND pr.production_id = mst.production_id)
    WHERE pr.member_id = ? $date_condition
    ORDER BY pr.date_created DESC";

    error_log("Balance summary query: " . str_replace('?', $member_id, $query));
    
    $stmt = $db->conn->prepare($query);
    if (!$stmt) {
        throw new Exception("Balance query prepare failed: " . $db->conn->error);
    }

    $stmt->bind_param("i", $member_id);
    if (!$stmt->execute()) {
        throw new Exception("Balance query execute failed: " . $stmt->error);
    }

    $result = $stmt->get_result();
    if (!$result) {
        throw new Exception("Balance query result failed: " . $stmt->error);
    }

    $balance_data = [];
    while ($row = $result->fetch_assoc()) {
        // Format the data
        $row['weight_g'] = $row['weight_g'] ? number_format($row['weight_g'], 3) : '-';
        $row['unit_rate'] = number_format($row['unit_rate'], 2);
        $row['total_amount'] = number_format($row['total_amount'], 2);
        $row['date_paid'] = $row['date_paid'] ? date('Y-m-d H:i', strtotime($row['date_paid'])) : null;
        $row['date_created'] = date('Y-m-d H:i', strtotime($row['date_created']));
        
        $balance_data[] = $row;
    }
    $stmt->close();

    // Calculate earnings summary
    $summary_query = "SELECT 
        COUNT(*) as total_tasks,
        SUM(CASE WHEN payment_status = 'Pending' THEN total_amount ELSE 0 END) as pending_payments,
        SUM(CASE WHEN payment_status = 'Paid' THEN total_amount ELSE 0 END) as completed_payments,
        SUM(total_amount) as total_earnings
    FROM payment_records 
    WHERE member_id = ?";
    
    error_log("Summary query: " . str_replace('?', $member_id, $summary_query));

    $stmt = $db->conn->prepare($summary_query);
    if (!$stmt) {
        throw new Exception("Summary query prepare failed: " . $db->conn->error);
    }

    $stmt->bind_param("i", $member_id);
    if (!$stmt->execute()) {
        throw new Exception("Summary query execute failed: " . $stmt->error);
    }

    $summary_result = $stmt->get_result();
    if (!$summary_result) {
        throw new Exception("Summary query result failed: " . $stmt->error);
    }

    $summary = $summary_result->fetch_assoc();
    if ($summary) {
        $summary['total_earnings'] = number_format($summary['total_earnings'], 2);
        $summary['pending_payments'] = number_format($summary['pending_payments'], 2);
        $summary['completed_payments'] = number_format($summary['completed_payments'], 2);
    }
    $stmt->close();

    echo json_encode([
        'success' => true,
        'data' => $balance_data,
        'summary' => $summary,
        'member_role' => $member_role
    ]);

} catch (Exception $e) {
    error_log("Error in get_balance_summary.php: " . $e->getMessage());
    error_log("Stack trace: " . $e->getTraceAsString());
    echo json_encode([
        'success' => false,
        'message' => 'Error fetching balance summary: ' . $e->getMessage()
    ]);
}
?>