<?php
session_start();
require_once '../../../function/database.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Not logged in'
    ]);
    exit;
}

$db = new Database();
$member_id = $_SESSION['id'];
$filter = $_GET['filter'] ?? 'all';

try {
    // Prepare date filter condition
    $date_condition = '';
    switch ($filter) {
        case 'this_month':
            $date_condition = 'AND MONTH(pr.date_created) = MONTH(CURRENT_DATE()) AND YEAR(pr.date_created) = YEAR(CURRENT_DATE())';
            break;
        case 'last_month':
            $date_condition = 'AND MONTH(pr.date_created) = MONTH(DATE_SUB(CURRENT_DATE(), INTERVAL 1 MONTH)) AND YEAR(pr.date_created) = YEAR(DATE_SUB(CURRENT_DATE(), INTERVAL 1 MONTH))';
            break;
        case 'this_year':
            $date_condition = 'AND YEAR(pr.date_created) = YEAR(CURRENT_DATE())';
            break;
        default:
            $date_condition = '';
    }

    // Get completed tasks and earnings from payment_records
    $query = "SELECT 
        pr.id as task_id,
        CASE 
            WHEN pr.is_self_assigned = 1 THEN mst.product_name
            ELSE pl.product_name
        END as product_name,
        pr.date_created as completion_date,
        pr.total_amount as amount,
        pr.payment_status
    FROM payment_records pr
    LEFT JOIN production_line pl ON (pr.is_self_assigned = 0 AND CAST(pr.production_id AS UNSIGNED) = pl.prod_line_id)
    LEFT JOIN member_self_tasks mst ON (pr.is_self_assigned = 1 AND pr.production_id = mst.production_id)
    WHERE pr.member_id = ? 
    $date_condition
    ORDER BY pr.date_created DESC";

    $stmt = $db->conn->prepare($query);
    if (!$stmt) {
        throw new Exception("Query preparation failed: " . $db->conn->error);
    }

    $stmt->bind_param("i", $member_id);
    if (!$stmt->execute()) {
        throw new Exception("Query execution failed: " . $stmt->error);
    }

    $result = $stmt->get_result();
    if (!$result) {
        throw new Exception("Failed to get result: " . $stmt->error);
    }

    $earnings = [];
    $total_earnings = 0;
    $pending_payments = 0;
    $completed_tasks = 0;

    while ($row = $result->fetch_assoc()) {
        $earnings[] = [
            'task_id' => $row['task_id'],
            'product_name' => $row['product_name'],
            'completion_date' => date('Y-m-d', strtotime($row['completion_date'])),
            'amount' => floatval($row['amount']),
            'payment_status' => $row['payment_status']
        ];

        $completed_tasks++;
        if ($row['payment_status'] === 'Paid') {
            $total_earnings += $row['amount'];
        } else {
            $pending_payments += $row['amount'];
        }
    }

    echo json_encode([
        'success' => true,
        'earnings' => $earnings,
        'total_earnings' => $total_earnings,
        'pending_payments' => $pending_payments,
        'completed_tasks' => $completed_tasks
    ]);

} catch (Exception $e) {
    error_log("Error in get_member_earnings.php: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?> 