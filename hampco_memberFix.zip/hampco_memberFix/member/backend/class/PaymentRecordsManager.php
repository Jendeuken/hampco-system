<?php

class PaymentRecordsManager {
    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    public function fetchPaymentRecords($memberId) {
        $query = "SELECT 
            pr.id,
            pr.production_id,
            CASE 
                WHEN pr.is_self_assigned = 1 THEN mst.product_name
                ELSE pl.product_name
            END as product_name,
            pr.length_m,
            pr.width_m,
            pr.weight_g,
            pr.quantity,
            pr.unit_rate,
            pr.total_amount,
            pr.payment_status,
            pr.date_paid
        FROM payment_records pr
        LEFT JOIN production_line pl ON (pr.is_self_assigned = 0 AND CAST(pr.production_id AS UNSIGNED) = pl.prod_line_id)
        LEFT JOIN member_self_tasks mst ON (pr.is_self_assigned = 1 AND pr.production_id = mst.production_id)
        WHERE pr.member_id = ?";

        $stmt = $this->conn->prepare($query);
        if (!$stmt) {
            throw new Exception("Failed to prepare query: " . $this->conn->error);
        }

        $stmt->bind_param("i", $memberId);
        if (!$stmt->execute()) {
            throw new Exception("Failed to execute query: " . $stmt->error);
        }

        $result = $stmt->get_result();
        $paymentRecords = [];

        while ($row = $result->fetch_assoc()) {
            $paymentRecords[] = $row;
        }

        $stmt->close();
        return $paymentRecords;
    }
} 